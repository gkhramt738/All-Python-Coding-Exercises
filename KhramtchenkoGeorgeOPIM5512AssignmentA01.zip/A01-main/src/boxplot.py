# Handle imports
from sklearn.datasets import fetch_california_housing
import pandas as pd
import matplotlib.pyplot as plt

# Load California Housing dataset
housing = fetch_california_housing(as_frame=True)

# Combined features and target into a single DataFrame
df = housing.frame

# perform a quick check to ensure previous operation succeded
print(df.head())
print(df.shape)

# Create a boxplot for the HouseAge and MedHouseVal columns with title and label
df.boxplot(column=['HouseAge', 'MedHouseVal'])
plt.title('Boxplot of HouseAge vs MedHouseVal')
plt.ylabel('Value')
plt.show()

# Save the boxplot as boxplot.png into the figs folder
plt.savefig('figs/boxplot.png')