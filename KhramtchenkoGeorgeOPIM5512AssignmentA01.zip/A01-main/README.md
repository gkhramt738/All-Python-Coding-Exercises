# A01 Assignment Repository

This repository contains the code and all relevant information for the A01 assignment. The California Housing dataset is used for this assignment.
The expected output of the script contained within this repository is a saved boxplot image of one aspect of the data.

To run this script, either clone or download the entire repository folder as a .ZIP folder. Once ready to proceed, either unzip the folder or navigate to the folder containing the python executable and double-click, or navigate to the working directory through the command line. Ensure you haave python installed to be able to run Python files! Once the file has run, you should see the boxplot.png saved in the **figs** folder.
