import aspose.words as aw

doc = aw.Document()
builder = aw.DocumentBuilder(doc)

builder.insert_image("Figure_1.png")

doc.save("Output.txt")