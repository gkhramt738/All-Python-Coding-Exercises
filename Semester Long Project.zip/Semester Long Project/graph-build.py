import matplotlib.pyplot as plt

left_coordinates=[1,2,3,4,5]
heights=[2,3,5,2,1]
bar_labels=['A','B','C','D','F']
plt.bar(left_coordinates,heights,tick_label=bar_labels,width=0.6,color=['green','blue','yellow','gray','black'])
plt.xlabel('Grade Distrbiution')
plt.ylabel('Number of Students')
plt.title("Grade Distribution Graph")
plt.show()